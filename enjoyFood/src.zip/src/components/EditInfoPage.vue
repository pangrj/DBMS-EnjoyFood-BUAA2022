
<script lang="ts">
export default {
    data(){
        return {
        }
    },
    methods: {
    }
}

import { ref } from 'vue'

</script>

<template>
  <div class="wholePage">
      
  </div>
</template>

<style>
.wholePage{
  padding-top: 3%;
}
.avatar-uploader .avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>

<style>

</style>
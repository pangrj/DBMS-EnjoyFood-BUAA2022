
<template>
  <div class="greetings">
    <h1 class="green">Enjoy Food!!</h1>
    <h3>
      Welcome to Enjoy Food !
    </h3>
  </div>
</template>

<script>
  export default {};
</script>

<style scoped>
.greetings { 
  text-align: center;
  font-size:36pt;
}
</style>
  